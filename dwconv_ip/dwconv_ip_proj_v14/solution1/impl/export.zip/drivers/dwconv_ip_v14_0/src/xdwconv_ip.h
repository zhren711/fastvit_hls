// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XDWCONV_IP_H
#define XDWCONV_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xdwconv_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XDwconv_ip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XDwconv_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDwconv_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDwconv_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDwconv_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDwconv_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XDwconv_ip_Initialize(XDwconv_ip *InstancePtr, UINTPTR BaseAddress);
XDwconv_ip_Config* XDwconv_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XDwconv_ip_Initialize(XDwconv_ip *InstancePtr, u16 DeviceId);
XDwconv_ip_Config* XDwconv_ip_LookupConfig(u16 DeviceId);
#endif
int XDwconv_ip_CfgInitialize(XDwconv_ip *InstancePtr, XDwconv_ip_Config *ConfigPtr);
#else
int XDwconv_ip_Initialize(XDwconv_ip *InstancePtr, const char* InstanceName);
int XDwconv_ip_Release(XDwconv_ip *InstancePtr);
#endif

void XDwconv_ip_Start(XDwconv_ip *InstancePtr);
u32 XDwconv_ip_IsDone(XDwconv_ip *InstancePtr);
u32 XDwconv_ip_IsIdle(XDwconv_ip *InstancePtr);
u32 XDwconv_ip_IsReady(XDwconv_ip *InstancePtr);
void XDwconv_ip_EnableAutoRestart(XDwconv_ip *InstancePtr);
void XDwconv_ip_DisableAutoRestart(XDwconv_ip *InstancePtr);

void XDwconv_ip_Set_feat_in(XDwconv_ip *InstancePtr, u64 Data);
u64 XDwconv_ip_Get_feat_in(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_weight(XDwconv_ip *InstancePtr, u64 Data);
u64 XDwconv_ip_Get_weight(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_bias(XDwconv_ip *InstancePtr, u64 Data);
u64 XDwconv_ip_Get_bias(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_feat_out(XDwconv_ip *InstancePtr, u64 Data);
u64 XDwconv_ip_Get_feat_out(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_CHin(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_CHin(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_Hin(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_Hin(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_Win(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_Win(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_Kh(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_Kh(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_Kw(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_Kw(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_stride_h(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_stride_h(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_stride_w(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_stride_w(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_pad_h(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_pad_h(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_pad_w(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_pad_w(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_fpg(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_fpg(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_act_mode(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_act_mode(XDwconv_ip *InstancePtr);
void XDwconv_ip_Set_out_shift(XDwconv_ip *InstancePtr, u32 Data);
u32 XDwconv_ip_Get_out_shift(XDwconv_ip *InstancePtr);

void XDwconv_ip_InterruptGlobalEnable(XDwconv_ip *InstancePtr);
void XDwconv_ip_InterruptGlobalDisable(XDwconv_ip *InstancePtr);
void XDwconv_ip_InterruptEnable(XDwconv_ip *InstancePtr, u32 Mask);
void XDwconv_ip_InterruptDisable(XDwconv_ip *InstancePtr, u32 Mask);
void XDwconv_ip_InterruptClear(XDwconv_ip *InstancePtr, u32 Mask);
u32 XDwconv_ip_InterruptGetEnabled(XDwconv_ip *InstancePtr);
u32 XDwconv_ip_InterruptGetStatus(XDwconv_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
