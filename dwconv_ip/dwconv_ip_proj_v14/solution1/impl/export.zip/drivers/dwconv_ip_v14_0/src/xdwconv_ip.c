// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xdwconv_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDwconv_ip_CfgInitialize(XDwconv_ip *InstancePtr, XDwconv_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDwconv_ip_Start(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDwconv_ip_IsDone(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDwconv_ip_IsIdle(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDwconv_ip_IsReady(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDwconv_ip_EnableAutoRestart(XDwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XDwconv_ip_DisableAutoRestart(XDwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XDwconv_ip_Set_feat_in(XDwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_IN_DATA, (u32)(Data));
    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_ip_Get_feat_in(XDwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_IN_DATA);
    Data += (u64)XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_IN_DATA + 4) << 32;
    return Data;
}

void XDwconv_ip_Set_weight(XDwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_WEIGHT_DATA, (u32)(Data));
    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_ip_Get_weight(XDwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_WEIGHT_DATA);
    Data += (u64)XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XDwconv_ip_Set_bias(XDwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_ip_Get_bias(XDwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XDwconv_ip_Set_feat_out(XDwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA, (u32)(Data));
    XDwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_ip_Get_feat_out(XDwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA);
    Data += (u64)XDwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XDwconv_ip_Set_CHin(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_CHIN_DATA, Data);
}

u32 XDwconv_ip_Get_CHin(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_CHIN_DATA);
    return Data;
}

void XDwconv_ip_Set_Hin(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_HIN_DATA, Data);
}

u32 XDwconv_ip_Get_Hin(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XDwconv_ip_Set_Win(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_WIN_DATA, Data);
}

u32 XDwconv_ip_Get_Win(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XDwconv_ip_Set_Kh(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_KH_DATA, Data);
}

u32 XDwconv_ip_Get_Kh(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_KH_DATA);
    return Data;
}

void XDwconv_ip_Set_Kw(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_KW_DATA, Data);
}

u32 XDwconv_ip_Get_Kw(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_KW_DATA);
    return Data;
}

void XDwconv_ip_Set_stride_h(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_STRIDE_H_DATA, Data);
}

u32 XDwconv_ip_Get_stride_h(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_STRIDE_H_DATA);
    return Data;
}

void XDwconv_ip_Set_stride_w(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_STRIDE_W_DATA, Data);
}

u32 XDwconv_ip_Get_stride_w(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_STRIDE_W_DATA);
    return Data;
}

void XDwconv_ip_Set_pad_h(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_PAD_H_DATA, Data);
}

u32 XDwconv_ip_Get_pad_h(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_PAD_H_DATA);
    return Data;
}

void XDwconv_ip_Set_pad_w(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_PAD_W_DATA, Data);
}

u32 XDwconv_ip_Get_pad_w(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_PAD_W_DATA);
    return Data;
}

void XDwconv_ip_Set_fpg(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_FPG_DATA, Data);
}

u32 XDwconv_ip_Get_fpg(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_FPG_DATA);
    return Data;
}

void XDwconv_ip_Set_act_mode(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_ACT_MODE_DATA, Data);
}

u32 XDwconv_ip_Get_act_mode(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_ACT_MODE_DATA);
    return Data;
}

void XDwconv_ip_Set_out_shift(XDwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_OUT_SHIFT_DATA, Data);
}

u32 XDwconv_ip_Get_out_shift(XDwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_OUT_SHIFT_DATA);
    return Data;
}

void XDwconv_ip_InterruptGlobalEnable(XDwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_GIE, 1);
}

void XDwconv_ip_InterruptGlobalDisable(XDwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_GIE, 0);
}

void XDwconv_ip_InterruptEnable(XDwconv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_IER);
    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_IER, Register | Mask);
}

void XDwconv_ip_InterruptDisable(XDwconv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_IER);
    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XDwconv_ip_InterruptClear(XDwconv_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_ISR, Mask);
}

u32 XDwconv_ip_InterruptGetEnabled(XDwconv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_IER);
}

u32 XDwconv_ip_InterruptGetStatus(XDwconv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_IP_CTRL_ADDR_ISR);
}

