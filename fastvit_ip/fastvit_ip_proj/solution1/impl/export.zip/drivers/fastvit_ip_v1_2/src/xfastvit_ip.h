// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XFASTVIT_IP_H
#define XFASTVIT_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xfastvit_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XFastvit_ip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XFastvit_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XFastvit_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XFastvit_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XFastvit_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XFastvit_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XFastvit_ip_Initialize(XFastvit_ip *InstancePtr, UINTPTR BaseAddress);
XFastvit_ip_Config* XFastvit_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XFastvit_ip_Initialize(XFastvit_ip *InstancePtr, u16 DeviceId);
XFastvit_ip_Config* XFastvit_ip_LookupConfig(u16 DeviceId);
#endif
int XFastvit_ip_CfgInitialize(XFastvit_ip *InstancePtr, XFastvit_ip_Config *ConfigPtr);
#else
int XFastvit_ip_Initialize(XFastvit_ip *InstancePtr, const char* InstanceName);
int XFastvit_ip_Release(XFastvit_ip *InstancePtr);
#endif

void XFastvit_ip_Start(XFastvit_ip *InstancePtr);
u32 XFastvit_ip_IsDone(XFastvit_ip *InstancePtr);
u32 XFastvit_ip_IsIdle(XFastvit_ip *InstancePtr);
u32 XFastvit_ip_IsReady(XFastvit_ip *InstancePtr);
void XFastvit_ip_EnableAutoRestart(XFastvit_ip *InstancePtr);
void XFastvit_ip_DisableAutoRestart(XFastvit_ip *InstancePtr);

void XFastvit_ip_Set_in_a(XFastvit_ip *InstancePtr, u64 Data);
u64 XFastvit_ip_Get_in_a(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_in_b(XFastvit_ip *InstancePtr, u64 Data);
u64 XFastvit_ip_Get_in_b(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_bias(XFastvit_ip *InstancePtr, u64 Data);
u64 XFastvit_ip_Get_bias(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_out_r(XFastvit_ip *InstancePtr, u64 Data);
u64 XFastvit_ip_Get_out_r(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_op_code(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_op_code(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_CHin(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_CHin(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_Hin(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_Hin(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_Win(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_Win(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_CHout(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_CHout(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_act_mode(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_act_mode(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_out_shift(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_out_shift(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_stride_h(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_stride_h(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_stride_w(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_stride_w(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_pad_h(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_pad_h(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_pad_w(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_pad_w(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_Kh(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_Kh(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_Kw(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_Kw(XFastvit_ip *InstancePtr);
void XFastvit_ip_Set_fpg(XFastvit_ip *InstancePtr, u32 Data);
u32 XFastvit_ip_Get_fpg(XFastvit_ip *InstancePtr);

void XFastvit_ip_InterruptGlobalEnable(XFastvit_ip *InstancePtr);
void XFastvit_ip_InterruptGlobalDisable(XFastvit_ip *InstancePtr);
void XFastvit_ip_InterruptEnable(XFastvit_ip *InstancePtr, u32 Mask);
void XFastvit_ip_InterruptDisable(XFastvit_ip *InstancePtr, u32 Mask);
void XFastvit_ip_InterruptClear(XFastvit_ip *InstancePtr, u32 Mask);
u32 XFastvit_ip_InterruptGetEnabled(XFastvit_ip *InstancePtr);
u32 XFastvit_ip_InterruptGetStatus(XFastvit_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
