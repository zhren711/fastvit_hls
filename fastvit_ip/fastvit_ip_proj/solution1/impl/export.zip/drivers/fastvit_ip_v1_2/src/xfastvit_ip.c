// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xfastvit_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFastvit_ip_CfgInitialize(XFastvit_ip *InstancePtr, XFastvit_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFastvit_ip_Start(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFastvit_ip_IsDone(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFastvit_ip_IsIdle(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFastvit_ip_IsReady(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFastvit_ip_EnableAutoRestart(XFastvit_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XFastvit_ip_DisableAutoRestart(XFastvit_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XFastvit_ip_Set_in_a(XFastvit_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_A_DATA, (u32)(Data));
    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_A_DATA + 4, (u32)(Data >> 32));
}

u64 XFastvit_ip_Get_in_a(XFastvit_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_A_DATA);
    Data += (u64)XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_A_DATA + 4) << 32;
    return Data;
}

void XFastvit_ip_Set_in_b(XFastvit_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_B_DATA, (u32)(Data));
    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_B_DATA + 4, (u32)(Data >> 32));
}

u64 XFastvit_ip_Get_in_b(XFastvit_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_B_DATA);
    Data += (u64)XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_IN_B_DATA + 4) << 32;
    return Data;
}

void XFastvit_ip_Set_bias(XFastvit_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XFastvit_ip_Get_bias(XFastvit_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XFastvit_ip_Set_out_r(XFastvit_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_OUT_R_DATA, (u32)(Data));
    XFastvit_ip_WriteReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XFastvit_ip_Get_out_r(XFastvit_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_OUT_R_DATA);
    Data += (u64)XFastvit_ip_ReadReg(InstancePtr->Control_BaseAddress, XFASTVIT_IP_CONTROL_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XFastvit_ip_Set_op_code(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_OP_CODE_DATA, Data);
}

u32 XFastvit_ip_Get_op_code(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_OP_CODE_DATA);
    return Data;
}

void XFastvit_ip_Set_CHin(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_CHIN_DATA, Data);
}

u32 XFastvit_ip_Get_CHin(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_CHIN_DATA);
    return Data;
}

void XFastvit_ip_Set_Hin(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_HIN_DATA, Data);
}

u32 XFastvit_ip_Get_Hin(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XFastvit_ip_Set_Win(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_WIN_DATA, Data);
}

u32 XFastvit_ip_Get_Win(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XFastvit_ip_Set_CHout(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_CHOUT_DATA, Data);
}

u32 XFastvit_ip_Get_CHout(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_CHOUT_DATA);
    return Data;
}

void XFastvit_ip_Set_act_mode(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_ACT_MODE_DATA, Data);
}

u32 XFastvit_ip_Get_act_mode(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_ACT_MODE_DATA);
    return Data;
}

void XFastvit_ip_Set_out_shift(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_OUT_SHIFT_DATA, Data);
}

u32 XFastvit_ip_Get_out_shift(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_OUT_SHIFT_DATA);
    return Data;
}

void XFastvit_ip_Set_stride_h(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_STRIDE_H_DATA, Data);
}

u32 XFastvit_ip_Get_stride_h(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_STRIDE_H_DATA);
    return Data;
}

void XFastvit_ip_Set_stride_w(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_STRIDE_W_DATA, Data);
}

u32 XFastvit_ip_Get_stride_w(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_STRIDE_W_DATA);
    return Data;
}

void XFastvit_ip_Set_pad_h(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_PAD_H_DATA, Data);
}

u32 XFastvit_ip_Get_pad_h(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_PAD_H_DATA);
    return Data;
}

void XFastvit_ip_Set_pad_w(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_PAD_W_DATA, Data);
}

u32 XFastvit_ip_Get_pad_w(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_PAD_W_DATA);
    return Data;
}

void XFastvit_ip_Set_Kh(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_KH_DATA, Data);
}

u32 XFastvit_ip_Get_Kh(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_KH_DATA);
    return Data;
}

void XFastvit_ip_Set_Kw(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_KW_DATA, Data);
}

u32 XFastvit_ip_Get_Kw(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_KW_DATA);
    return Data;
}

void XFastvit_ip_Set_fpg(XFastvit_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_FPG_DATA, Data);
}

u32 XFastvit_ip_Get_fpg(XFastvit_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_FPG_DATA);
    return Data;
}

void XFastvit_ip_InterruptGlobalEnable(XFastvit_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_GIE, 1);
}

void XFastvit_ip_InterruptGlobalDisable(XFastvit_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_GIE, 0);
}

void XFastvit_ip_InterruptEnable(XFastvit_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_IER);
    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_IER, Register | Mask);
}

void XFastvit_ip_InterruptDisable(XFastvit_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_IER);
    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XFastvit_ip_InterruptClear(XFastvit_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFastvit_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_ISR, Mask);
}

u32 XFastvit_ip_InterruptGetEnabled(XFastvit_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_IER);
}

u32 XFastvit_ip_InterruptGetStatus(XFastvit_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFastvit_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XFASTVIT_IP_CTRL_ADDR_ISR);
}

