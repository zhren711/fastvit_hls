// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xdwconv3_ip.h"

extern XDwconv3_ip_Config XDwconv3_ip_ConfigTable[];

#ifdef SDT
XDwconv3_ip_Config *XDwconv3_ip_LookupConfig(UINTPTR BaseAddress) {
	XDwconv3_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XDwconv3_ip_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XDwconv3_ip_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XDwconv3_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDwconv3_ip_Initialize(XDwconv3_ip *InstancePtr, UINTPTR BaseAddress) {
	XDwconv3_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDwconv3_ip_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDwconv3_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XDwconv3_ip_Config *XDwconv3_ip_LookupConfig(u16 DeviceId) {
	XDwconv3_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDWCONV3_IP_NUM_INSTANCES; Index++) {
		if (XDwconv3_ip_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDwconv3_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDwconv3_ip_Initialize(XDwconv3_ip *InstancePtr, u16 DeviceId) {
	XDwconv3_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDwconv3_ip_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDwconv3_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

