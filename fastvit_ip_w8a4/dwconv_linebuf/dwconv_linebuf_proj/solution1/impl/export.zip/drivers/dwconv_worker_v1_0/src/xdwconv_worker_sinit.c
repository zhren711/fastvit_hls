// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xdwconv_worker.h"

extern XDwconv_worker_Config XDwconv_worker_ConfigTable[];

#ifdef SDT
XDwconv_worker_Config *XDwconv_worker_LookupConfig(UINTPTR BaseAddress) {
	XDwconv_worker_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XDwconv_worker_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XDwconv_worker_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XDwconv_worker_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDwconv_worker_Initialize(XDwconv_worker *InstancePtr, UINTPTR BaseAddress) {
	XDwconv_worker_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDwconv_worker_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDwconv_worker_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XDwconv_worker_Config *XDwconv_worker_LookupConfig(u16 DeviceId) {
	XDwconv_worker_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDWCONV_WORKER_NUM_INSTANCES; Index++) {
		if (XDwconv_worker_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDwconv_worker_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDwconv_worker_Initialize(XDwconv_worker *InstancePtr, u16 DeviceId) {
	XDwconv_worker_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDwconv_worker_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDwconv_worker_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

