// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xdwconv_worker.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDwconv_worker_CfgInitialize(XDwconv_worker *InstancePtr, XDwconv_worker_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDwconv_worker_Start(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_AP_CTRL) & 0x80;
    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDwconv_worker_IsDone(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDwconv_worker_IsIdle(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDwconv_worker_IsReady(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDwconv_worker_EnableAutoRestart(XDwconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_AP_CTRL, 0x80);
}

void XDwconv_worker_DisableAutoRestart(XDwconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_AP_CTRL, 0);
}

void XDwconv_worker_Set_feat_in(XDwconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_IN_DATA, (u32)(Data));
    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_worker_Get_feat_in(XDwconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_IN_DATA);
    Data += (u64)XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_IN_DATA + 4) << 32;
    return Data;
}

void XDwconv_worker_Set_weight(XDwconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_WEIGHT_DATA, (u32)(Data));
    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_worker_Get_weight(XDwconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_WEIGHT_DATA);
    Data += (u64)XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XDwconv_worker_Set_bias(XDwconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_worker_Get_bias(XDwconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XDwconv_worker_Set_feat_out(XDwconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_OUT_DATA, (u32)(Data));
    XDwconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv_worker_Get_feat_out(XDwconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_OUT_DATA);
    Data += (u64)XDwconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV_WORKER_CONTROL_ADDR_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XDwconv_worker_Set_CHin(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_CHIN_DATA, Data);
}

u32 XDwconv_worker_Get_CHin(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_CHIN_DATA);
    return Data;
}

void XDwconv_worker_Set_Hin(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_HIN_DATA, Data);
}

u32 XDwconv_worker_Get_Hin(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XDwconv_worker_Set_Win(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_WIN_DATA, Data);
}

u32 XDwconv_worker_Get_Win(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XDwconv_worker_Set_Kh(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_KH_DATA, Data);
}

u32 XDwconv_worker_Get_Kh(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_KH_DATA);
    return Data;
}

void XDwconv_worker_Set_Kw(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_KW_DATA, Data);
}

u32 XDwconv_worker_Get_Kw(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_KW_DATA);
    return Data;
}

void XDwconv_worker_Set_stride_h(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_STRIDE_H_DATA, Data);
}

u32 XDwconv_worker_Get_stride_h(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_STRIDE_H_DATA);
    return Data;
}

void XDwconv_worker_Set_stride_w(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_STRIDE_W_DATA, Data);
}

u32 XDwconv_worker_Get_stride_w(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_STRIDE_W_DATA);
    return Data;
}

void XDwconv_worker_Set_pad_h(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_PAD_H_DATA, Data);
}

u32 XDwconv_worker_Get_pad_h(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_PAD_H_DATA);
    return Data;
}

void XDwconv_worker_Set_pad_w(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_PAD_W_DATA, Data);
}

u32 XDwconv_worker_Get_pad_w(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_PAD_W_DATA);
    return Data;
}

void XDwconv_worker_Set_fpg(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_FPG_DATA, Data);
}

u32 XDwconv_worker_Get_fpg(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_FPG_DATA);
    return Data;
}

void XDwconv_worker_Set_act_mode(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_ACT_MODE_DATA, Data);
}

u32 XDwconv_worker_Get_act_mode(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_ACT_MODE_DATA);
    return Data;
}

void XDwconv_worker_Set_out_shift(XDwconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_OUT_SHIFT_DATA, Data);
}

u32 XDwconv_worker_Get_out_shift(XDwconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_OUT_SHIFT_DATA);
    return Data;
}

void XDwconv_worker_InterruptGlobalEnable(XDwconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_GIE, 1);
}

void XDwconv_worker_InterruptGlobalDisable(XDwconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_GIE, 0);
}

void XDwconv_worker_InterruptEnable(XDwconv_worker *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_IER);
    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_IER, Register | Mask);
}

void XDwconv_worker_InterruptDisable(XDwconv_worker *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_IER);
    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_IER, Register & (~Mask));
}

void XDwconv_worker_InterruptClear(XDwconv_worker *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_ISR, Mask);
}

u32 XDwconv_worker_InterruptGetEnabled(XDwconv_worker *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_IER);
}

u32 XDwconv_worker_InterruptGetStatus(XDwconv_worker *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDwconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV_WORKER_CTRL_ADDR_ISR);
}

