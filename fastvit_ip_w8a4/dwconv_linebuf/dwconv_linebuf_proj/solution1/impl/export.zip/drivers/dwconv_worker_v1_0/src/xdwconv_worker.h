// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XDWCONV_WORKER_H
#define XDWCONV_WORKER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xdwconv_worker_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XDwconv_worker_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XDwconv_worker;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDwconv_worker_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDwconv_worker_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDwconv_worker_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDwconv_worker_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XDwconv_worker_Initialize(XDwconv_worker *InstancePtr, UINTPTR BaseAddress);
XDwconv_worker_Config* XDwconv_worker_LookupConfig(UINTPTR BaseAddress);
#else
int XDwconv_worker_Initialize(XDwconv_worker *InstancePtr, u16 DeviceId);
XDwconv_worker_Config* XDwconv_worker_LookupConfig(u16 DeviceId);
#endif
int XDwconv_worker_CfgInitialize(XDwconv_worker *InstancePtr, XDwconv_worker_Config *ConfigPtr);
#else
int XDwconv_worker_Initialize(XDwconv_worker *InstancePtr, const char* InstanceName);
int XDwconv_worker_Release(XDwconv_worker *InstancePtr);
#endif

void XDwconv_worker_Start(XDwconv_worker *InstancePtr);
u32 XDwconv_worker_IsDone(XDwconv_worker *InstancePtr);
u32 XDwconv_worker_IsIdle(XDwconv_worker *InstancePtr);
u32 XDwconv_worker_IsReady(XDwconv_worker *InstancePtr);
void XDwconv_worker_EnableAutoRestart(XDwconv_worker *InstancePtr);
void XDwconv_worker_DisableAutoRestart(XDwconv_worker *InstancePtr);

void XDwconv_worker_Set_feat_in(XDwconv_worker *InstancePtr, u64 Data);
u64 XDwconv_worker_Get_feat_in(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_weight(XDwconv_worker *InstancePtr, u64 Data);
u64 XDwconv_worker_Get_weight(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_bias(XDwconv_worker *InstancePtr, u64 Data);
u64 XDwconv_worker_Get_bias(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_feat_out(XDwconv_worker *InstancePtr, u64 Data);
u64 XDwconv_worker_Get_feat_out(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_CHin(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_CHin(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_Hin(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_Hin(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_Win(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_Win(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_Kh(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_Kh(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_Kw(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_Kw(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_stride_h(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_stride_h(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_stride_w(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_stride_w(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_pad_h(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_pad_h(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_pad_w(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_pad_w(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_fpg(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_fpg(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_act_mode(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_act_mode(XDwconv_worker *InstancePtr);
void XDwconv_worker_Set_out_shift(XDwconv_worker *InstancePtr, u32 Data);
u32 XDwconv_worker_Get_out_shift(XDwconv_worker *InstancePtr);

void XDwconv_worker_InterruptGlobalEnable(XDwconv_worker *InstancePtr);
void XDwconv_worker_InterruptGlobalDisable(XDwconv_worker *InstancePtr);
void XDwconv_worker_InterruptEnable(XDwconv_worker *InstancePtr, u32 Mask);
void XDwconv_worker_InterruptDisable(XDwconv_worker *InstancePtr, u32 Mask);
void XDwconv_worker_InterruptClear(XDwconv_worker *InstancePtr, u32 Mask);
u32 XDwconv_worker_InterruptGetEnabled(XDwconv_worker *InstancePtr);
u32 XDwconv_worker_InterruptGetStatus(XDwconv_worker *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
