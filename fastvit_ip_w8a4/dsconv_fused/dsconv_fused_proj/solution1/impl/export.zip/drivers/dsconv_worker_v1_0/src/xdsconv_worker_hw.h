// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of dw_feat_in
//        bit 31~0 - dw_feat_in[31:0] (Read/Write)
// 0x14 : Data signal of dw_feat_in
//        bit 31~0 - dw_feat_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of dw_weight
//        bit 31~0 - dw_weight[31:0] (Read/Write)
// 0x20 : Data signal of dw_weight
//        bit 31~0 - dw_weight[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of dw_bias
//        bit 31~0 - dw_bias[31:0] (Read/Write)
// 0x2c : Data signal of dw_bias
//        bit 31~0 - dw_bias[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of dw_feat_out
//        bit 31~0 - dw_feat_out[31:0] (Read/Write)
// 0x38 : Data signal of dw_feat_out
//        bit 31~0 - dw_feat_out[63:32] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of pw_weight
//        bit 31~0 - pw_weight[31:0] (Read/Write)
// 0x44 : Data signal of pw_weight
//        bit 31~0 - pw_weight[63:32] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of pw_bias
//        bit 31~0 - pw_bias[31:0] (Read/Write)
// 0x50 : Data signal of pw_bias
//        bit 31~0 - pw_bias[63:32] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of pw_feat_out
//        bit 31~0 - pw_feat_out[31:0] (Read/Write)
// 0x5c : Data signal of pw_feat_out
//        bit 31~0 - pw_feat_out[63:32] (Read/Write)
// 0x60 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_IN_DATA  0x10
#define XDSCONV_WORKER_CONTROL_BITS_DW_FEAT_IN_DATA  64
#define XDSCONV_WORKER_CONTROL_ADDR_DW_WEIGHT_DATA   0x1c
#define XDSCONV_WORKER_CONTROL_BITS_DW_WEIGHT_DATA   64
#define XDSCONV_WORKER_CONTROL_ADDR_DW_BIAS_DATA     0x28
#define XDSCONV_WORKER_CONTROL_BITS_DW_BIAS_DATA     64
#define XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_OUT_DATA 0x34
#define XDSCONV_WORKER_CONTROL_BITS_DW_FEAT_OUT_DATA 64
#define XDSCONV_WORKER_CONTROL_ADDR_PW_WEIGHT_DATA   0x40
#define XDSCONV_WORKER_CONTROL_BITS_PW_WEIGHT_DATA   64
#define XDSCONV_WORKER_CONTROL_ADDR_PW_BIAS_DATA     0x4c
#define XDSCONV_WORKER_CONTROL_BITS_PW_BIAS_DATA     64
#define XDSCONV_WORKER_CONTROL_ADDR_PW_FEAT_OUT_DATA 0x58
#define XDSCONV_WORKER_CONTROL_BITS_PW_FEAT_OUT_DATA 64

// ctrl
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of CHin
//        bit 31~0 - CHin[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of Hin
//        bit 31~0 - Hin[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of Win
//        bit 31~0 - Win[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of Kh
//        bit 31~0 - Kh[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of Kw
//        bit 31~0 - Kw[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of pad_h
//        bit 31~0 - pad_h[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of pad_w
//        bit 31~0 - pad_w[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of CHout
//        bit 31~0 - CHout[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of dw_act_mode
//        bit 31~0 - dw_act_mode[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of dw_out_shift
//        bit 31~0 - dw_out_shift[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of pw_act_mode
//        bit 31~0 - pw_act_mode[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of pw_out_shift
//        bit 31~0 - pw_out_shift[31:0] (Read/Write)
// 0x6c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XDSCONV_WORKER_CTRL_ADDR_AP_CTRL           0x00
#define XDSCONV_WORKER_CTRL_ADDR_GIE               0x04
#define XDSCONV_WORKER_CTRL_ADDR_IER               0x08
#define XDSCONV_WORKER_CTRL_ADDR_ISR               0x0c
#define XDSCONV_WORKER_CTRL_ADDR_CHIN_DATA         0x10
#define XDSCONV_WORKER_CTRL_BITS_CHIN_DATA         32
#define XDSCONV_WORKER_CTRL_ADDR_HIN_DATA          0x18
#define XDSCONV_WORKER_CTRL_BITS_HIN_DATA          32
#define XDSCONV_WORKER_CTRL_ADDR_WIN_DATA          0x20
#define XDSCONV_WORKER_CTRL_BITS_WIN_DATA          32
#define XDSCONV_WORKER_CTRL_ADDR_KH_DATA           0x28
#define XDSCONV_WORKER_CTRL_BITS_KH_DATA           32
#define XDSCONV_WORKER_CTRL_ADDR_KW_DATA           0x30
#define XDSCONV_WORKER_CTRL_BITS_KW_DATA           32
#define XDSCONV_WORKER_CTRL_ADDR_PAD_H_DATA        0x38
#define XDSCONV_WORKER_CTRL_BITS_PAD_H_DATA        32
#define XDSCONV_WORKER_CTRL_ADDR_PAD_W_DATA        0x40
#define XDSCONV_WORKER_CTRL_BITS_PAD_W_DATA        32
#define XDSCONV_WORKER_CTRL_ADDR_CHOUT_DATA        0x48
#define XDSCONV_WORKER_CTRL_BITS_CHOUT_DATA        32
#define XDSCONV_WORKER_CTRL_ADDR_DW_ACT_MODE_DATA  0x50
#define XDSCONV_WORKER_CTRL_BITS_DW_ACT_MODE_DATA  32
#define XDSCONV_WORKER_CTRL_ADDR_DW_OUT_SHIFT_DATA 0x58
#define XDSCONV_WORKER_CTRL_BITS_DW_OUT_SHIFT_DATA 32
#define XDSCONV_WORKER_CTRL_ADDR_PW_ACT_MODE_DATA  0x60
#define XDSCONV_WORKER_CTRL_BITS_PW_ACT_MODE_DATA  32
#define XDSCONV_WORKER_CTRL_ADDR_PW_OUT_SHIFT_DATA 0x68
#define XDSCONV_WORKER_CTRL_BITS_PW_OUT_SHIFT_DATA 32

