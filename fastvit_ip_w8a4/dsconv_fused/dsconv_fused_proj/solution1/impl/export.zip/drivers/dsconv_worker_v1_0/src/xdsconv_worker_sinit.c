// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xdsconv_worker.h"

extern XDsconv_worker_Config XDsconv_worker_ConfigTable[];

#ifdef SDT
XDsconv_worker_Config *XDsconv_worker_LookupConfig(UINTPTR BaseAddress) {
	XDsconv_worker_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XDsconv_worker_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XDsconv_worker_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XDsconv_worker_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDsconv_worker_Initialize(XDsconv_worker *InstancePtr, UINTPTR BaseAddress) {
	XDsconv_worker_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDsconv_worker_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDsconv_worker_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XDsconv_worker_Config *XDsconv_worker_LookupConfig(u16 DeviceId) {
	XDsconv_worker_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDSCONV_WORKER_NUM_INSTANCES; Index++) {
		if (XDsconv_worker_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDsconv_worker_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDsconv_worker_Initialize(XDsconv_worker *InstancePtr, u16 DeviceId) {
	XDsconv_worker_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDsconv_worker_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDsconv_worker_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

