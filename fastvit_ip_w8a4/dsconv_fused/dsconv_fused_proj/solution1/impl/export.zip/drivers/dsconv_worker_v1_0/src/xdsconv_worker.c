// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xdsconv_worker.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDsconv_worker_CfgInitialize(XDsconv_worker *InstancePtr, XDsconv_worker_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDsconv_worker_Start(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_AP_CTRL) & 0x80;
    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDsconv_worker_IsDone(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDsconv_worker_IsIdle(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDsconv_worker_IsReady(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDsconv_worker_EnableAutoRestart(XDsconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_AP_CTRL, 0x80);
}

void XDsconv_worker_DisableAutoRestart(XDsconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_AP_CTRL, 0);
}

void XDsconv_worker_Set_dw_feat_in(XDsconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_IN_DATA, (u32)(Data));
    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XDsconv_worker_Get_dw_feat_in(XDsconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_IN_DATA);
    Data += (u64)XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_IN_DATA + 4) << 32;
    return Data;
}

void XDsconv_worker_Set_dw_weight(XDsconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_WEIGHT_DATA, (u32)(Data));
    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XDsconv_worker_Get_dw_weight(XDsconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_WEIGHT_DATA);
    Data += (u64)XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XDsconv_worker_Set_dw_bias(XDsconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_BIAS_DATA, (u32)(Data));
    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XDsconv_worker_Get_dw_bias(XDsconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_BIAS_DATA);
    Data += (u64)XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_BIAS_DATA + 4) << 32;
    return Data;
}

void XDsconv_worker_Set_dw_feat_out(XDsconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_OUT_DATA, (u32)(Data));
    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XDsconv_worker_Get_dw_feat_out(XDsconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_OUT_DATA);
    Data += (u64)XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_DW_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XDsconv_worker_Set_pw_weight(XDsconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_WEIGHT_DATA, (u32)(Data));
    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XDsconv_worker_Get_pw_weight(XDsconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_WEIGHT_DATA);
    Data += (u64)XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XDsconv_worker_Set_pw_bias(XDsconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_BIAS_DATA, (u32)(Data));
    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XDsconv_worker_Get_pw_bias(XDsconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_BIAS_DATA);
    Data += (u64)XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_BIAS_DATA + 4) << 32;
    return Data;
}

void XDsconv_worker_Set_pw_feat_out(XDsconv_worker *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_FEAT_OUT_DATA, (u32)(Data));
    XDsconv_worker_WriteReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XDsconv_worker_Get_pw_feat_out(XDsconv_worker *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_FEAT_OUT_DATA);
    Data += (u64)XDsconv_worker_ReadReg(InstancePtr->Control_BaseAddress, XDSCONV_WORKER_CONTROL_ADDR_PW_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XDsconv_worker_Set_CHin(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_CHIN_DATA, Data);
}

u32 XDsconv_worker_Get_CHin(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_CHIN_DATA);
    return Data;
}

void XDsconv_worker_Set_Hin(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_HIN_DATA, Data);
}

u32 XDsconv_worker_Get_Hin(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XDsconv_worker_Set_Win(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_WIN_DATA, Data);
}

u32 XDsconv_worker_Get_Win(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XDsconv_worker_Set_Kh(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_KH_DATA, Data);
}

u32 XDsconv_worker_Get_Kh(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_KH_DATA);
    return Data;
}

void XDsconv_worker_Set_Kw(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_KW_DATA, Data);
}

u32 XDsconv_worker_Get_Kw(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_KW_DATA);
    return Data;
}

void XDsconv_worker_Set_pad_h(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PAD_H_DATA, Data);
}

u32 XDsconv_worker_Get_pad_h(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PAD_H_DATA);
    return Data;
}

void XDsconv_worker_Set_pad_w(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PAD_W_DATA, Data);
}

u32 XDsconv_worker_Get_pad_w(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PAD_W_DATA);
    return Data;
}

void XDsconv_worker_Set_CHout(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_CHOUT_DATA, Data);
}

u32 XDsconv_worker_Get_CHout(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_CHOUT_DATA);
    return Data;
}

void XDsconv_worker_Set_dw_act_mode(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_DW_ACT_MODE_DATA, Data);
}

u32 XDsconv_worker_Get_dw_act_mode(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_DW_ACT_MODE_DATA);
    return Data;
}

void XDsconv_worker_Set_dw_out_shift(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_DW_OUT_SHIFT_DATA, Data);
}

u32 XDsconv_worker_Get_dw_out_shift(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_DW_OUT_SHIFT_DATA);
    return Data;
}

void XDsconv_worker_Set_pw_act_mode(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PW_ACT_MODE_DATA, Data);
}

u32 XDsconv_worker_Get_pw_act_mode(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PW_ACT_MODE_DATA);
    return Data;
}

void XDsconv_worker_Set_pw_out_shift(XDsconv_worker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PW_OUT_SHIFT_DATA, Data);
}

u32 XDsconv_worker_Get_pw_out_shift(XDsconv_worker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_PW_OUT_SHIFT_DATA);
    return Data;
}

void XDsconv_worker_InterruptGlobalEnable(XDsconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_GIE, 1);
}

void XDsconv_worker_InterruptGlobalDisable(XDsconv_worker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_GIE, 0);
}

void XDsconv_worker_InterruptEnable(XDsconv_worker *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_IER);
    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_IER, Register | Mask);
}

void XDsconv_worker_InterruptDisable(XDsconv_worker *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_IER);
    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_IER, Register & (~Mask));
}

void XDsconv_worker_InterruptClear(XDsconv_worker *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsconv_worker_WriteReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_ISR, Mask);
}

u32 XDsconv_worker_InterruptGetEnabled(XDsconv_worker *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_IER);
}

u32 XDsconv_worker_InterruptGetStatus(XDsconv_worker *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDsconv_worker_ReadReg(InstancePtr->Ctrl_BaseAddress, XDSCONV_WORKER_CTRL_ADDR_ISR);
}

