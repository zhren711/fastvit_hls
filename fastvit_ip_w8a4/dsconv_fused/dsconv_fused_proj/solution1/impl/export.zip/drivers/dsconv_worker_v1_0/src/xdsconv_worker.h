// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XDSCONV_WORKER_H
#define XDSCONV_WORKER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xdsconv_worker_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XDsconv_worker_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XDsconv_worker;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDsconv_worker_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDsconv_worker_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDsconv_worker_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDsconv_worker_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XDsconv_worker_Initialize(XDsconv_worker *InstancePtr, UINTPTR BaseAddress);
XDsconv_worker_Config* XDsconv_worker_LookupConfig(UINTPTR BaseAddress);
#else
int XDsconv_worker_Initialize(XDsconv_worker *InstancePtr, u16 DeviceId);
XDsconv_worker_Config* XDsconv_worker_LookupConfig(u16 DeviceId);
#endif
int XDsconv_worker_CfgInitialize(XDsconv_worker *InstancePtr, XDsconv_worker_Config *ConfigPtr);
#else
int XDsconv_worker_Initialize(XDsconv_worker *InstancePtr, const char* InstanceName);
int XDsconv_worker_Release(XDsconv_worker *InstancePtr);
#endif

void XDsconv_worker_Start(XDsconv_worker *InstancePtr);
u32 XDsconv_worker_IsDone(XDsconv_worker *InstancePtr);
u32 XDsconv_worker_IsIdle(XDsconv_worker *InstancePtr);
u32 XDsconv_worker_IsReady(XDsconv_worker *InstancePtr);
void XDsconv_worker_EnableAutoRestart(XDsconv_worker *InstancePtr);
void XDsconv_worker_DisableAutoRestart(XDsconv_worker *InstancePtr);

void XDsconv_worker_Set_dw_feat_in(XDsconv_worker *InstancePtr, u64 Data);
u64 XDsconv_worker_Get_dw_feat_in(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_dw_weight(XDsconv_worker *InstancePtr, u64 Data);
u64 XDsconv_worker_Get_dw_weight(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_dw_bias(XDsconv_worker *InstancePtr, u64 Data);
u64 XDsconv_worker_Get_dw_bias(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_dw_feat_out(XDsconv_worker *InstancePtr, u64 Data);
u64 XDsconv_worker_Get_dw_feat_out(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_pw_weight(XDsconv_worker *InstancePtr, u64 Data);
u64 XDsconv_worker_Get_pw_weight(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_pw_bias(XDsconv_worker *InstancePtr, u64 Data);
u64 XDsconv_worker_Get_pw_bias(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_pw_feat_out(XDsconv_worker *InstancePtr, u64 Data);
u64 XDsconv_worker_Get_pw_feat_out(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_CHin(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_CHin(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_Hin(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_Hin(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_Win(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_Win(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_Kh(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_Kh(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_Kw(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_Kw(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_pad_h(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_pad_h(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_pad_w(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_pad_w(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_CHout(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_CHout(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_dw_act_mode(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_dw_act_mode(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_dw_out_shift(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_dw_out_shift(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_pw_act_mode(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_pw_act_mode(XDsconv_worker *InstancePtr);
void XDsconv_worker_Set_pw_out_shift(XDsconv_worker *InstancePtr, u32 Data);
u32 XDsconv_worker_Get_pw_out_shift(XDsconv_worker *InstancePtr);

void XDsconv_worker_InterruptGlobalEnable(XDsconv_worker *InstancePtr);
void XDsconv_worker_InterruptGlobalDisable(XDsconv_worker *InstancePtr);
void XDsconv_worker_InterruptEnable(XDsconv_worker *InstancePtr, u32 Mask);
void XDsconv_worker_InterruptDisable(XDsconv_worker *InstancePtr, u32 Mask);
void XDsconv_worker_InterruptClear(XDsconv_worker *InstancePtr, u32 Mask);
u32 XDsconv_worker_InterruptGetEnabled(XDsconv_worker *InstancePtr);
u32 XDsconv_worker_InterruptGetStatus(XDsconv_worker *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
