// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xdwconv7_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDwconv7_ip_CfgInitialize(XDwconv7_ip *InstancePtr, XDwconv7_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDwconv7_ip_Start(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDwconv7_ip_IsDone(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDwconv7_ip_IsIdle(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDwconv7_ip_IsReady(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDwconv7_ip_EnableAutoRestart(XDwconv7_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XDwconv7_ip_DisableAutoRestart(XDwconv7_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XDwconv7_ip_Set_feat_in(XDwconv7_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_IN_DATA, (u32)(Data));
    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv7_ip_Get_feat_in(XDwconv7_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_IN_DATA);
    Data += (u64)XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_IN_DATA + 4) << 32;
    return Data;
}

void XDwconv7_ip_Set_weight(XDwconv7_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_WEIGHT_DATA, (u32)(Data));
    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv7_ip_Get_weight(XDwconv7_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_WEIGHT_DATA);
    Data += (u64)XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XDwconv7_ip_Set_bias(XDwconv7_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv7_ip_Get_bias(XDwconv7_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XDwconv7_ip_Set_feat_out(XDwconv7_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_OUT_DATA, (u32)(Data));
    XDwconv7_ip_WriteReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XDwconv7_ip_Get_feat_out(XDwconv7_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_OUT_DATA);
    Data += (u64)XDwconv7_ip_ReadReg(InstancePtr->Control_BaseAddress, XDWCONV7_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XDwconv7_ip_Set_CHin(XDwconv7_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_CHIN_DATA, Data);
}

u32 XDwconv7_ip_Get_CHin(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_CHIN_DATA);
    return Data;
}

void XDwconv7_ip_Set_Hin(XDwconv7_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_HIN_DATA, Data);
}

u32 XDwconv7_ip_Get_Hin(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XDwconv7_ip_Set_Win(XDwconv7_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_WIN_DATA, Data);
}

u32 XDwconv7_ip_Get_Win(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XDwconv7_ip_Set_act_mode(XDwconv7_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_ACT_MODE_DATA, Data);
}

u32 XDwconv7_ip_Get_act_mode(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_ACT_MODE_DATA);
    return Data;
}

void XDwconv7_ip_Set_out_shift(XDwconv7_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_OUT_SHIFT_DATA, Data);
}

u32 XDwconv7_ip_Get_out_shift(XDwconv7_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_OUT_SHIFT_DATA);
    return Data;
}

void XDwconv7_ip_InterruptGlobalEnable(XDwconv7_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_GIE, 1);
}

void XDwconv7_ip_InterruptGlobalDisable(XDwconv7_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_GIE, 0);
}

void XDwconv7_ip_InterruptEnable(XDwconv7_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_IER);
    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_IER, Register | Mask);
}

void XDwconv7_ip_InterruptDisable(XDwconv7_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_IER);
    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XDwconv7_ip_InterruptClear(XDwconv7_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDwconv7_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_ISR, Mask);
}

u32 XDwconv7_ip_InterruptGetEnabled(XDwconv7_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_IER);
}

u32 XDwconv7_ip_InterruptGetStatus(XDwconv7_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDwconv7_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XDWCONV7_IP_CTRL_ADDR_ISR);
}

