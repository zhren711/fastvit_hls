// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xdwconv7_ip.h"

extern XDwconv7_ip_Config XDwconv7_ip_ConfigTable[];

#ifdef SDT
XDwconv7_ip_Config *XDwconv7_ip_LookupConfig(UINTPTR BaseAddress) {
	XDwconv7_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XDwconv7_ip_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XDwconv7_ip_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XDwconv7_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDwconv7_ip_Initialize(XDwconv7_ip *InstancePtr, UINTPTR BaseAddress) {
	XDwconv7_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDwconv7_ip_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDwconv7_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XDwconv7_ip_Config *XDwconv7_ip_LookupConfig(u16 DeviceId) {
	XDwconv7_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDWCONV7_IP_NUM_INSTANCES; Index++) {
		if (XDwconv7_ip_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDwconv7_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDwconv7_ip_Initialize(XDwconv7_ip *InstancePtr, u16 DeviceId) {
	XDwconv7_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDwconv7_ip_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDwconv7_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

