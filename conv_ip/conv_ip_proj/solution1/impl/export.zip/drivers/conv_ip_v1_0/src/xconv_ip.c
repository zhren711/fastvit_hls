// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xconv_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XConv_ip_CfgInitialize(XConv_ip *InstancePtr, XConv_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XConv_ip_Start(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XConv_ip_IsDone(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XConv_ip_IsIdle(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XConv_ip_IsReady(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XConv_ip_EnableAutoRestart(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XConv_ip_DisableAutoRestart(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XConv_ip_Set_feat_in(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_IN_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_feat_in(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_IN_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_IN_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_weight(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WEIGHT_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_weight(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WEIGHT_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_bias(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_bias(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_feat_out(XConv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA, (u32)(Data));
    XConv_ip_WriteReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XConv_ip_Get_feat_out(XConv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA);
    Data += (u64)XConv_ip_ReadReg(InstancePtr->Control_BaseAddress, XCONV_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XConv_ip_Set_CHin(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_CHIN_DATA, Data);
}

u32 XConv_ip_Get_CHin(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_CHIN_DATA);
    return Data;
}

void XConv_ip_Set_Hin(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_HIN_DATA, Data);
}

u32 XConv_ip_Get_Hin(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XConv_ip_Set_Win(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_WIN_DATA, Data);
}

u32 XConv_ip_Get_Win(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XConv_ip_Set_CHout(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_CHOUT_DATA, Data);
}

u32 XConv_ip_Get_CHout(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_CHOUT_DATA);
    return Data;
}

void XConv_ip_Set_stride_h(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_STRIDE_H_DATA, Data);
}

u32 XConv_ip_Get_stride_h(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_STRIDE_H_DATA);
    return Data;
}

void XConv_ip_Set_stride_w(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_STRIDE_W_DATA, Data);
}

u32 XConv_ip_Get_stride_w(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_STRIDE_W_DATA);
    return Data;
}

void XConv_ip_Set_pad_h(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_PAD_H_DATA, Data);
}

u32 XConv_ip_Get_pad_h(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_PAD_H_DATA);
    return Data;
}

void XConv_ip_Set_pad_w(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_PAD_W_DATA, Data);
}

u32 XConv_ip_Get_pad_w(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_PAD_W_DATA);
    return Data;
}

void XConv_ip_Set_act_mode(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_ACT_MODE_DATA, Data);
}

u32 XConv_ip_Get_act_mode(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_ACT_MODE_DATA);
    return Data;
}

void XConv_ip_Set_out_shift(XConv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_OUT_SHIFT_DATA, Data);
}

u32 XConv_ip_Get_out_shift(XConv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_OUT_SHIFT_DATA);
    return Data;
}

void XConv_ip_InterruptGlobalEnable(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_GIE, 1);
}

void XConv_ip_InterruptGlobalDisable(XConv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_GIE, 0);
}

void XConv_ip_InterruptEnable(XConv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_IER);
    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_IER, Register | Mask);
}

void XConv_ip_InterruptDisable(XConv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_IER);
    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XConv_ip_InterruptClear(XConv_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XConv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_ISR, Mask);
}

u32 XConv_ip_InterruptGetEnabled(XConv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_IER);
}

u32 XConv_ip_InterruptGetStatus(XConv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XConv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XCONV_IP_CTRL_ADDR_ISR);
}

