// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XCONV_IP_H
#define XCONV_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xconv_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XConv_ip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XConv_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XConv_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XConv_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XConv_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XConv_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XConv_ip_Initialize(XConv_ip *InstancePtr, UINTPTR BaseAddress);
XConv_ip_Config* XConv_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XConv_ip_Initialize(XConv_ip *InstancePtr, u16 DeviceId);
XConv_ip_Config* XConv_ip_LookupConfig(u16 DeviceId);
#endif
int XConv_ip_CfgInitialize(XConv_ip *InstancePtr, XConv_ip_Config *ConfigPtr);
#else
int XConv_ip_Initialize(XConv_ip *InstancePtr, const char* InstanceName);
int XConv_ip_Release(XConv_ip *InstancePtr);
#endif

void XConv_ip_Start(XConv_ip *InstancePtr);
u32 XConv_ip_IsDone(XConv_ip *InstancePtr);
u32 XConv_ip_IsIdle(XConv_ip *InstancePtr);
u32 XConv_ip_IsReady(XConv_ip *InstancePtr);
void XConv_ip_EnableAutoRestart(XConv_ip *InstancePtr);
void XConv_ip_DisableAutoRestart(XConv_ip *InstancePtr);

void XConv_ip_Set_feat_in(XConv_ip *InstancePtr, u64 Data);
u64 XConv_ip_Get_feat_in(XConv_ip *InstancePtr);
void XConv_ip_Set_weight(XConv_ip *InstancePtr, u64 Data);
u64 XConv_ip_Get_weight(XConv_ip *InstancePtr);
void XConv_ip_Set_bias(XConv_ip *InstancePtr, u64 Data);
u64 XConv_ip_Get_bias(XConv_ip *InstancePtr);
void XConv_ip_Set_feat_out(XConv_ip *InstancePtr, u64 Data);
u64 XConv_ip_Get_feat_out(XConv_ip *InstancePtr);
void XConv_ip_Set_CHin(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_CHin(XConv_ip *InstancePtr);
void XConv_ip_Set_Hin(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_Hin(XConv_ip *InstancePtr);
void XConv_ip_Set_Win(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_Win(XConv_ip *InstancePtr);
void XConv_ip_Set_CHout(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_CHout(XConv_ip *InstancePtr);
void XConv_ip_Set_stride_h(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_stride_h(XConv_ip *InstancePtr);
void XConv_ip_Set_stride_w(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_stride_w(XConv_ip *InstancePtr);
void XConv_ip_Set_pad_h(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_pad_h(XConv_ip *InstancePtr);
void XConv_ip_Set_pad_w(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_pad_w(XConv_ip *InstancePtr);
void XConv_ip_Set_act_mode(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_act_mode(XConv_ip *InstancePtr);
void XConv_ip_Set_out_shift(XConv_ip *InstancePtr, u32 Data);
u32 XConv_ip_Get_out_shift(XConv_ip *InstancePtr);

void XConv_ip_InterruptGlobalEnable(XConv_ip *InstancePtr);
void XConv_ip_InterruptGlobalDisable(XConv_ip *InstancePtr);
void XConv_ip_InterruptEnable(XConv_ip *InstancePtr, u32 Mask);
void XConv_ip_InterruptDisable(XConv_ip *InstancePtr, u32 Mask);
void XConv_ip_InterruptClear(XConv_ip *InstancePtr, u32 Mask);
u32 XConv_ip_InterruptGetEnabled(XConv_ip *InstancePtr);
u32 XConv_ip_InterruptGetStatus(XConv_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
