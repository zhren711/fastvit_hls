// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XGLOBAL_AVGPOOL_IP_H
#define XGLOBAL_AVGPOOL_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xglobal_avgpool_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XGlobal_avgpool_ip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XGlobal_avgpool_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XGlobal_avgpool_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XGlobal_avgpool_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XGlobal_avgpool_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XGlobal_avgpool_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XGlobal_avgpool_ip_Initialize(XGlobal_avgpool_ip *InstancePtr, UINTPTR BaseAddress);
XGlobal_avgpool_ip_Config* XGlobal_avgpool_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XGlobal_avgpool_ip_Initialize(XGlobal_avgpool_ip *InstancePtr, u16 DeviceId);
XGlobal_avgpool_ip_Config* XGlobal_avgpool_ip_LookupConfig(u16 DeviceId);
#endif
int XGlobal_avgpool_ip_CfgInitialize(XGlobal_avgpool_ip *InstancePtr, XGlobal_avgpool_ip_Config *ConfigPtr);
#else
int XGlobal_avgpool_ip_Initialize(XGlobal_avgpool_ip *InstancePtr, const char* InstanceName);
int XGlobal_avgpool_ip_Release(XGlobal_avgpool_ip *InstancePtr);
#endif

void XGlobal_avgpool_ip_Start(XGlobal_avgpool_ip *InstancePtr);
u32 XGlobal_avgpool_ip_IsDone(XGlobal_avgpool_ip *InstancePtr);
u32 XGlobal_avgpool_ip_IsIdle(XGlobal_avgpool_ip *InstancePtr);
u32 XGlobal_avgpool_ip_IsReady(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_EnableAutoRestart(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_DisableAutoRestart(XGlobal_avgpool_ip *InstancePtr);

void XGlobal_avgpool_ip_Set_feat_in(XGlobal_avgpool_ip *InstancePtr, u64 Data);
u64 XGlobal_avgpool_ip_Get_feat_in(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_Set_feat_out(XGlobal_avgpool_ip *InstancePtr, u64 Data);
u64 XGlobal_avgpool_ip_Get_feat_out(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_Set_CH(XGlobal_avgpool_ip *InstancePtr, u32 Data);
u32 XGlobal_avgpool_ip_Get_CH(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_Set_Hin(XGlobal_avgpool_ip *InstancePtr, u32 Data);
u32 XGlobal_avgpool_ip_Get_Hin(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_Set_Win(XGlobal_avgpool_ip *InstancePtr, u32 Data);
u32 XGlobal_avgpool_ip_Get_Win(XGlobal_avgpool_ip *InstancePtr);

void XGlobal_avgpool_ip_InterruptGlobalEnable(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_InterruptGlobalDisable(XGlobal_avgpool_ip *InstancePtr);
void XGlobal_avgpool_ip_InterruptEnable(XGlobal_avgpool_ip *InstancePtr, u32 Mask);
void XGlobal_avgpool_ip_InterruptDisable(XGlobal_avgpool_ip *InstancePtr, u32 Mask);
void XGlobal_avgpool_ip_InterruptClear(XGlobal_avgpool_ip *InstancePtr, u32 Mask);
u32 XGlobal_avgpool_ip_InterruptGetEnabled(XGlobal_avgpool_ip *InstancePtr);
u32 XGlobal_avgpool_ip_InterruptGetStatus(XGlobal_avgpool_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
