// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xglobal_avgpool_ip.h"

extern XGlobal_avgpool_ip_Config XGlobal_avgpool_ip_ConfigTable[];

#ifdef SDT
XGlobal_avgpool_ip_Config *XGlobal_avgpool_ip_LookupConfig(UINTPTR BaseAddress) {
	XGlobal_avgpool_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XGlobal_avgpool_ip_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XGlobal_avgpool_ip_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XGlobal_avgpool_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGlobal_avgpool_ip_Initialize(XGlobal_avgpool_ip *InstancePtr, UINTPTR BaseAddress) {
	XGlobal_avgpool_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGlobal_avgpool_ip_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGlobal_avgpool_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XGlobal_avgpool_ip_Config *XGlobal_avgpool_ip_LookupConfig(u16 DeviceId) {
	XGlobal_avgpool_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XGLOBAL_AVGPOOL_IP_NUM_INSTANCES; Index++) {
		if (XGlobal_avgpool_ip_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XGlobal_avgpool_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGlobal_avgpool_ip_Initialize(XGlobal_avgpool_ip *InstancePtr, u16 DeviceId) {
	XGlobal_avgpool_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGlobal_avgpool_ip_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGlobal_avgpool_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

