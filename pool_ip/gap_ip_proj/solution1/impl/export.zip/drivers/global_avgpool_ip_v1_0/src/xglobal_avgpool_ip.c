// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xglobal_avgpool_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XGlobal_avgpool_ip_CfgInitialize(XGlobal_avgpool_ip *InstancePtr, XGlobal_avgpool_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XGlobal_avgpool_ip_Start(XGlobal_avgpool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XGlobal_avgpool_ip_IsDone(XGlobal_avgpool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XGlobal_avgpool_ip_IsIdle(XGlobal_avgpool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XGlobal_avgpool_ip_IsReady(XGlobal_avgpool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XGlobal_avgpool_ip_EnableAutoRestart(XGlobal_avgpool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XGlobal_avgpool_ip_DisableAutoRestart(XGlobal_avgpool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XGlobal_avgpool_ip_Set_feat_in(XGlobal_avgpool_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA, (u32)(Data));
    XGlobal_avgpool_ip_WriteReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XGlobal_avgpool_ip_Get_feat_in(XGlobal_avgpool_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA);
    Data += (u64)XGlobal_avgpool_ip_ReadReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA + 4) << 32;
    return Data;
}

void XGlobal_avgpool_ip_Set_feat_out(XGlobal_avgpool_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA, (u32)(Data));
    XGlobal_avgpool_ip_WriteReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XGlobal_avgpool_ip_Get_feat_out(XGlobal_avgpool_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA);
    Data += (u64)XGlobal_avgpool_ip_ReadReg(InstancePtr->Control_BaseAddress, XGLOBAL_AVGPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XGlobal_avgpool_ip_Set_CH(XGlobal_avgpool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_CH_DATA, Data);
}

u32 XGlobal_avgpool_ip_Get_CH(XGlobal_avgpool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_CH_DATA);
    return Data;
}

void XGlobal_avgpool_ip_Set_Hin(XGlobal_avgpool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_HIN_DATA, Data);
}

u32 XGlobal_avgpool_ip_Get_Hin(XGlobal_avgpool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XGlobal_avgpool_ip_Set_Win(XGlobal_avgpool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_WIN_DATA, Data);
}

u32 XGlobal_avgpool_ip_Get_Win(XGlobal_avgpool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XGlobal_avgpool_ip_InterruptGlobalEnable(XGlobal_avgpool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_GIE, 1);
}

void XGlobal_avgpool_ip_InterruptGlobalDisable(XGlobal_avgpool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_GIE, 0);
}

void XGlobal_avgpool_ip_InterruptEnable(XGlobal_avgpool_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_IER);
    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_IER, Register | Mask);
}

void XGlobal_avgpool_ip_InterruptDisable(XGlobal_avgpool_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_IER);
    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XGlobal_avgpool_ip_InterruptClear(XGlobal_avgpool_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGlobal_avgpool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_ISR, Mask);
}

u32 XGlobal_avgpool_ip_InterruptGetEnabled(XGlobal_avgpool_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_IER);
}

u32 XGlobal_avgpool_ip_InterruptGetStatus(XGlobal_avgpool_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGlobal_avgpool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XGLOBAL_AVGPOOL_IP_CTRL_ADDR_ISR);
}

