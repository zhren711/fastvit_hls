// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xpool_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPool_ip_CfgInitialize(XPool_ip *InstancePtr, XPool_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPool_ip_Start(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPool_ip_IsDone(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPool_ip_IsIdle(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPool_ip_IsReady(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPool_ip_EnableAutoRestart(XPool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XPool_ip_DisableAutoRestart(XPool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XPool_ip_Set_feat_in(XPool_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA, (u32)(Data));
    XPool_ip_WriteReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XPool_ip_Get_feat_in(XPool_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA);
    Data += (u64)XPool_ip_ReadReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_IN_DATA + 4) << 32;
    return Data;
}

void XPool_ip_Set_feat_out(XPool_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA, (u32)(Data));
    XPool_ip_WriteReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XPool_ip_Get_feat_out(XPool_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA);
    Data += (u64)XPool_ip_ReadReg(InstancePtr->Control_BaseAddress, XPOOL_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XPool_ip_Set_CH(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_CH_DATA, Data);
}

u32 XPool_ip_Get_CH(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_CH_DATA);
    return Data;
}

void XPool_ip_Set_Hin(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_HIN_DATA, Data);
}

u32 XPool_ip_Get_Hin(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_HIN_DATA);
    return Data;
}

void XPool_ip_Set_Win(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_WIN_DATA, Data);
}

u32 XPool_ip_Get_Win(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_WIN_DATA);
    return Data;
}

void XPool_ip_Set_Kh(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_KH_DATA, Data);
}

u32 XPool_ip_Get_Kh(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_KH_DATA);
    return Data;
}

void XPool_ip_Set_Kw(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_KW_DATA, Data);
}

u32 XPool_ip_Get_Kw(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_KW_DATA);
    return Data;
}

void XPool_ip_Set_stride_h(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_STRIDE_H_DATA, Data);
}

u32 XPool_ip_Get_stride_h(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_STRIDE_H_DATA);
    return Data;
}

void XPool_ip_Set_stride_w(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_STRIDE_W_DATA, Data);
}

u32 XPool_ip_Get_stride_w(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_STRIDE_W_DATA);
    return Data;
}

void XPool_ip_Set_pad_h(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_PAD_H_DATA, Data);
}

u32 XPool_ip_Get_pad_h(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_PAD_H_DATA);
    return Data;
}

void XPool_ip_Set_pad_w(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_PAD_W_DATA, Data);
}

u32 XPool_ip_Get_pad_w(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_PAD_W_DATA);
    return Data;
}

void XPool_ip_Set_mode(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_MODE_DATA, Data);
}

u32 XPool_ip_Get_mode(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_MODE_DATA);
    return Data;
}

void XPool_ip_Set_out_shift(XPool_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_OUT_SHIFT_DATA, Data);
}

u32 XPool_ip_Get_out_shift(XPool_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_OUT_SHIFT_DATA);
    return Data;
}

void XPool_ip_InterruptGlobalEnable(XPool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_GIE, 1);
}

void XPool_ip_InterruptGlobalDisable(XPool_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_GIE, 0);
}

void XPool_ip_InterruptEnable(XPool_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_IER);
    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_IER, Register | Mask);
}

void XPool_ip_InterruptDisable(XPool_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_IER);
    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XPool_ip_InterruptClear(XPool_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPool_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_ISR, Mask);
}

u32 XPool_ip_InterruptGetEnabled(XPool_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_IER);
}

u32 XPool_ip_InterruptGetStatus(XPool_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPool_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPOOL_IP_CTRL_ADDR_ISR);
}

