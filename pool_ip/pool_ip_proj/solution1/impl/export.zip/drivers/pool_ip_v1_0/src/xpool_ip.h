// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPOOL_IP_H
#define XPOOL_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xpool_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XPool_ip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XPool_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XPool_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XPool_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XPool_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XPool_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XPool_ip_Initialize(XPool_ip *InstancePtr, UINTPTR BaseAddress);
XPool_ip_Config* XPool_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XPool_ip_Initialize(XPool_ip *InstancePtr, u16 DeviceId);
XPool_ip_Config* XPool_ip_LookupConfig(u16 DeviceId);
#endif
int XPool_ip_CfgInitialize(XPool_ip *InstancePtr, XPool_ip_Config *ConfigPtr);
#else
int XPool_ip_Initialize(XPool_ip *InstancePtr, const char* InstanceName);
int XPool_ip_Release(XPool_ip *InstancePtr);
#endif

void XPool_ip_Start(XPool_ip *InstancePtr);
u32 XPool_ip_IsDone(XPool_ip *InstancePtr);
u32 XPool_ip_IsIdle(XPool_ip *InstancePtr);
u32 XPool_ip_IsReady(XPool_ip *InstancePtr);
void XPool_ip_EnableAutoRestart(XPool_ip *InstancePtr);
void XPool_ip_DisableAutoRestart(XPool_ip *InstancePtr);

void XPool_ip_Set_feat_in(XPool_ip *InstancePtr, u64 Data);
u64 XPool_ip_Get_feat_in(XPool_ip *InstancePtr);
void XPool_ip_Set_feat_out(XPool_ip *InstancePtr, u64 Data);
u64 XPool_ip_Get_feat_out(XPool_ip *InstancePtr);
void XPool_ip_Set_CH(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_CH(XPool_ip *InstancePtr);
void XPool_ip_Set_Hin(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_Hin(XPool_ip *InstancePtr);
void XPool_ip_Set_Win(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_Win(XPool_ip *InstancePtr);
void XPool_ip_Set_Kh(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_Kh(XPool_ip *InstancePtr);
void XPool_ip_Set_Kw(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_Kw(XPool_ip *InstancePtr);
void XPool_ip_Set_stride_h(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_stride_h(XPool_ip *InstancePtr);
void XPool_ip_Set_stride_w(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_stride_w(XPool_ip *InstancePtr);
void XPool_ip_Set_pad_h(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_pad_h(XPool_ip *InstancePtr);
void XPool_ip_Set_pad_w(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_pad_w(XPool_ip *InstancePtr);
void XPool_ip_Set_mode(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_mode(XPool_ip *InstancePtr);
void XPool_ip_Set_out_shift(XPool_ip *InstancePtr, u32 Data);
u32 XPool_ip_Get_out_shift(XPool_ip *InstancePtr);

void XPool_ip_InterruptGlobalEnable(XPool_ip *InstancePtr);
void XPool_ip_InterruptGlobalDisable(XPool_ip *InstancePtr);
void XPool_ip_InterruptEnable(XPool_ip *InstancePtr, u32 Mask);
void XPool_ip_InterruptDisable(XPool_ip *InstancePtr, u32 Mask);
void XPool_ip_InterruptClear(XPool_ip *InstancePtr, u32 Mask);
u32 XPool_ip_InterruptGetEnabled(XPool_ip *InstancePtr);
u32 XPool_ip_InterruptGetStatus(XPool_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
