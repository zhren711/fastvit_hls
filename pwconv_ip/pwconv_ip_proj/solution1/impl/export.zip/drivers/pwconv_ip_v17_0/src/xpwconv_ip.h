// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPWCONV_IP_H
#define XPWCONV_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xpwconv_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XPwconv_ip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XPwconv_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XPwconv_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XPwconv_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XPwconv_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XPwconv_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XPwconv_ip_Initialize(XPwconv_ip *InstancePtr, UINTPTR BaseAddress);
XPwconv_ip_Config* XPwconv_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XPwconv_ip_Initialize(XPwconv_ip *InstancePtr, u16 DeviceId);
XPwconv_ip_Config* XPwconv_ip_LookupConfig(u16 DeviceId);
#endif
int XPwconv_ip_CfgInitialize(XPwconv_ip *InstancePtr, XPwconv_ip_Config *ConfigPtr);
#else
int XPwconv_ip_Initialize(XPwconv_ip *InstancePtr, const char* InstanceName);
int XPwconv_ip_Release(XPwconv_ip *InstancePtr);
#endif

void XPwconv_ip_Start(XPwconv_ip *InstancePtr);
u32 XPwconv_ip_IsDone(XPwconv_ip *InstancePtr);
u32 XPwconv_ip_IsIdle(XPwconv_ip *InstancePtr);
u32 XPwconv_ip_IsReady(XPwconv_ip *InstancePtr);
void XPwconv_ip_EnableAutoRestart(XPwconv_ip *InstancePtr);
void XPwconv_ip_DisableAutoRestart(XPwconv_ip *InstancePtr);

void XPwconv_ip_Set_feat_in_w32(XPwconv_ip *InstancePtr, u64 Data);
u64 XPwconv_ip_Get_feat_in_w32(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_weight(XPwconv_ip *InstancePtr, u64 Data);
u64 XPwconv_ip_Get_weight(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_bias(XPwconv_ip *InstancePtr, u64 Data);
u64 XPwconv_ip_Get_bias(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_feat_out_w32(XPwconv_ip *InstancePtr, u64 Data);
u64 XPwconv_ip_Get_feat_out_w32(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_CHin(XPwconv_ip *InstancePtr, u32 Data);
u32 XPwconv_ip_Get_CHin(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_H(XPwconv_ip *InstancePtr, u32 Data);
u32 XPwconv_ip_Get_H(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_W(XPwconv_ip *InstancePtr, u32 Data);
u32 XPwconv_ip_Get_W(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_CHout(XPwconv_ip *InstancePtr, u32 Data);
u32 XPwconv_ip_Get_CHout(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_act_mode(XPwconv_ip *InstancePtr, u32 Data);
u32 XPwconv_ip_Get_act_mode(XPwconv_ip *InstancePtr);
void XPwconv_ip_Set_out_shift(XPwconv_ip *InstancePtr, u32 Data);
u32 XPwconv_ip_Get_out_shift(XPwconv_ip *InstancePtr);

void XPwconv_ip_InterruptGlobalEnable(XPwconv_ip *InstancePtr);
void XPwconv_ip_InterruptGlobalDisable(XPwconv_ip *InstancePtr);
void XPwconv_ip_InterruptEnable(XPwconv_ip *InstancePtr, u32 Mask);
void XPwconv_ip_InterruptDisable(XPwconv_ip *InstancePtr, u32 Mask);
void XPwconv_ip_InterruptClear(XPwconv_ip *InstancePtr, u32 Mask);
u32 XPwconv_ip_InterruptGetEnabled(XPwconv_ip *InstancePtr);
u32 XPwconv_ip_InterruptGetStatus(XPwconv_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
