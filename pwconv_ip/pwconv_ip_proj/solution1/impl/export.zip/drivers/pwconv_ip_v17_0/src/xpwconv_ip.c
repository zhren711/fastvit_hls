// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xpwconv_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPwconv_ip_CfgInitialize(XPwconv_ip *InstancePtr, XPwconv_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPwconv_ip_Start(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPwconv_ip_IsDone(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPwconv_ip_IsIdle(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPwconv_ip_IsReady(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPwconv_ip_EnableAutoRestart(XPwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XPwconv_ip_DisableAutoRestart(XPwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XPwconv_ip_Set_feat_in_w32(XPwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_IN_W32_DATA, (u32)(Data));
    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_IN_W32_DATA + 4, (u32)(Data >> 32));
}

u64 XPwconv_ip_Get_feat_in_w32(XPwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_IN_W32_DATA);
    Data += (u64)XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_IN_W32_DATA + 4) << 32;
    return Data;
}

void XPwconv_ip_Set_weight(XPwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_WEIGHT_DATA, (u32)(Data));
    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XPwconv_ip_Get_weight(XPwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_WEIGHT_DATA);
    Data += (u64)XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XPwconv_ip_Set_bias(XPwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_BIAS_DATA, (u32)(Data));
    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_BIAS_DATA + 4, (u32)(Data >> 32));
}

u64 XPwconv_ip_Get_bias(XPwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_BIAS_DATA);
    Data += (u64)XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_BIAS_DATA + 4) << 32;
    return Data;
}

void XPwconv_ip_Set_feat_out_w32(XPwconv_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_OUT_W32_DATA, (u32)(Data));
    XPwconv_ip_WriteReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_OUT_W32_DATA + 4, (u32)(Data >> 32));
}

u64 XPwconv_ip_Get_feat_out_w32(XPwconv_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_OUT_W32_DATA);
    Data += (u64)XPwconv_ip_ReadReg(InstancePtr->Control_BaseAddress, XPWCONV_IP_CONTROL_ADDR_FEAT_OUT_W32_DATA + 4) << 32;
    return Data;
}

void XPwconv_ip_Set_CHin(XPwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_CHIN_DATA, Data);
}

u32 XPwconv_ip_Get_CHin(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_CHIN_DATA);
    return Data;
}

void XPwconv_ip_Set_H(XPwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_H_DATA, Data);
}

u32 XPwconv_ip_Get_H(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_H_DATA);
    return Data;
}

void XPwconv_ip_Set_W(XPwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_W_DATA, Data);
}

u32 XPwconv_ip_Get_W(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_W_DATA);
    return Data;
}

void XPwconv_ip_Set_CHout(XPwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_CHOUT_DATA, Data);
}

u32 XPwconv_ip_Get_CHout(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_CHOUT_DATA);
    return Data;
}

void XPwconv_ip_Set_act_mode(XPwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_ACT_MODE_DATA, Data);
}

u32 XPwconv_ip_Get_act_mode(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_ACT_MODE_DATA);
    return Data;
}

void XPwconv_ip_Set_out_shift(XPwconv_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_OUT_SHIFT_DATA, Data);
}

u32 XPwconv_ip_Get_out_shift(XPwconv_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_OUT_SHIFT_DATA);
    return Data;
}

void XPwconv_ip_InterruptGlobalEnable(XPwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_GIE, 1);
}

void XPwconv_ip_InterruptGlobalDisable(XPwconv_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_GIE, 0);
}

void XPwconv_ip_InterruptEnable(XPwconv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_IER);
    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_IER, Register | Mask);
}

void XPwconv_ip_InterruptDisable(XPwconv_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_IER);
    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XPwconv_ip_InterruptClear(XPwconv_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPwconv_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_ISR, Mask);
}

u32 XPwconv_ip_InterruptGetEnabled(XPwconv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_IER);
}

u32 XPwconv_ip_InterruptGetStatus(XPwconv_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPwconv_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XPWCONV_IP_CTRL_ADDR_ISR);
}

