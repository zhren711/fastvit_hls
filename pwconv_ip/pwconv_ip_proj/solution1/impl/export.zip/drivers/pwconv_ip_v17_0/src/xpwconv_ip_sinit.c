// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xpwconv_ip.h"

extern XPwconv_ip_Config XPwconv_ip_ConfigTable[];

#ifdef SDT
XPwconv_ip_Config *XPwconv_ip_LookupConfig(UINTPTR BaseAddress) {
	XPwconv_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XPwconv_ip_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XPwconv_ip_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XPwconv_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPwconv_ip_Initialize(XPwconv_ip *InstancePtr, UINTPTR BaseAddress) {
	XPwconv_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPwconv_ip_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPwconv_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XPwconv_ip_Config *XPwconv_ip_LookupConfig(u16 DeviceId) {
	XPwconv_ip_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XPWCONV_IP_NUM_INSTANCES; Index++) {
		if (XPwconv_ip_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XPwconv_ip_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPwconv_ip_Initialize(XPwconv_ip *InstancePtr, u16 DeviceId) {
	XPwconv_ip_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPwconv_ip_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPwconv_ip_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

