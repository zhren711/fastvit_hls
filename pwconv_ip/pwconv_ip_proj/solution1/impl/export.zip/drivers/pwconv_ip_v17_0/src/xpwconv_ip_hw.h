// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of feat_in_w32
//        bit 31~0 - feat_in_w32[31:0] (Read/Write)
// 0x14 : Data signal of feat_in_w32
//        bit 31~0 - feat_in_w32[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of weight
//        bit 31~0 - weight[31:0] (Read/Write)
// 0x20 : Data signal of weight
//        bit 31~0 - weight[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of bias
//        bit 31~0 - bias[31:0] (Read/Write)
// 0x2c : Data signal of bias
//        bit 31~0 - bias[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of feat_out_w32
//        bit 31~0 - feat_out_w32[31:0] (Read/Write)
// 0x38 : Data signal of feat_out_w32
//        bit 31~0 - feat_out_w32[63:32] (Read/Write)
// 0x3c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPWCONV_IP_CONTROL_ADDR_FEAT_IN_W32_DATA  0x10
#define XPWCONV_IP_CONTROL_BITS_FEAT_IN_W32_DATA  64
#define XPWCONV_IP_CONTROL_ADDR_WEIGHT_DATA       0x1c
#define XPWCONV_IP_CONTROL_BITS_WEIGHT_DATA       64
#define XPWCONV_IP_CONTROL_ADDR_BIAS_DATA         0x28
#define XPWCONV_IP_CONTROL_BITS_BIAS_DATA         64
#define XPWCONV_IP_CONTROL_ADDR_FEAT_OUT_W32_DATA 0x34
#define XPWCONV_IP_CONTROL_BITS_FEAT_OUT_W32_DATA 64

// ctrl
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of CHin
//        bit 31~0 - CHin[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of H
//        bit 31~0 - H[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of W
//        bit 31~0 - W[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of CHout
//        bit 31~0 - CHout[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of act_mode
//        bit 31~0 - act_mode[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of out_shift
//        bit 31~0 - out_shift[31:0] (Read/Write)
// 0x3c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPWCONV_IP_CTRL_ADDR_AP_CTRL        0x00
#define XPWCONV_IP_CTRL_ADDR_GIE            0x04
#define XPWCONV_IP_CTRL_ADDR_IER            0x08
#define XPWCONV_IP_CTRL_ADDR_ISR            0x0c
#define XPWCONV_IP_CTRL_ADDR_CHIN_DATA      0x10
#define XPWCONV_IP_CTRL_BITS_CHIN_DATA      32
#define XPWCONV_IP_CTRL_ADDR_H_DATA         0x18
#define XPWCONV_IP_CTRL_BITS_H_DATA         32
#define XPWCONV_IP_CTRL_ADDR_W_DATA         0x20
#define XPWCONV_IP_CTRL_BITS_W_DATA         32
#define XPWCONV_IP_CTRL_ADDR_CHOUT_DATA     0x28
#define XPWCONV_IP_CTRL_BITS_CHOUT_DATA     32
#define XPWCONV_IP_CTRL_ADDR_ACT_MODE_DATA  0x30
#define XPWCONV_IP_CTRL_BITS_ACT_MODE_DATA  32
#define XPWCONV_IP_CTRL_ADDR_OUT_SHIFT_DATA 0x38
#define XPWCONV_IP_CTRL_BITS_OUT_SHIFT_DATA 32

