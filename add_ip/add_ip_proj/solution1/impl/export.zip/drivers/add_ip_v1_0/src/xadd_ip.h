// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XADD_IP_H
#define XADD_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xadd_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XAdd_ip_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XAdd_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAdd_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAdd_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAdd_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAdd_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XAdd_ip_Initialize(XAdd_ip *InstancePtr, UINTPTR BaseAddress);
XAdd_ip_Config* XAdd_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XAdd_ip_Initialize(XAdd_ip *InstancePtr, u16 DeviceId);
XAdd_ip_Config* XAdd_ip_LookupConfig(u16 DeviceId);
#endif
int XAdd_ip_CfgInitialize(XAdd_ip *InstancePtr, XAdd_ip_Config *ConfigPtr);
#else
int XAdd_ip_Initialize(XAdd_ip *InstancePtr, const char* InstanceName);
int XAdd_ip_Release(XAdd_ip *InstancePtr);
#endif

void XAdd_ip_Start(XAdd_ip *InstancePtr);
u32 XAdd_ip_IsDone(XAdd_ip *InstancePtr);
u32 XAdd_ip_IsIdle(XAdd_ip *InstancePtr);
u32 XAdd_ip_IsReady(XAdd_ip *InstancePtr);
void XAdd_ip_EnableAutoRestart(XAdd_ip *InstancePtr);
void XAdd_ip_DisableAutoRestart(XAdd_ip *InstancePtr);

void XAdd_ip_Set_feat_in1(XAdd_ip *InstancePtr, u64 Data);
u64 XAdd_ip_Get_feat_in1(XAdd_ip *InstancePtr);
void XAdd_ip_Set_feat_in2(XAdd_ip *InstancePtr, u64 Data);
u64 XAdd_ip_Get_feat_in2(XAdd_ip *InstancePtr);
void XAdd_ip_Set_feat_out(XAdd_ip *InstancePtr, u64 Data);
u64 XAdd_ip_Get_feat_out(XAdd_ip *InstancePtr);
void XAdd_ip_Set_CH(XAdd_ip *InstancePtr, u32 Data);
u32 XAdd_ip_Get_CH(XAdd_ip *InstancePtr);
void XAdd_ip_Set_H(XAdd_ip *InstancePtr, u32 Data);
u32 XAdd_ip_Get_H(XAdd_ip *InstancePtr);
void XAdd_ip_Set_W(XAdd_ip *InstancePtr, u32 Data);
u32 XAdd_ip_Get_W(XAdd_ip *InstancePtr);

void XAdd_ip_InterruptGlobalEnable(XAdd_ip *InstancePtr);
void XAdd_ip_InterruptGlobalDisable(XAdd_ip *InstancePtr);
void XAdd_ip_InterruptEnable(XAdd_ip *InstancePtr, u32 Mask);
void XAdd_ip_InterruptDisable(XAdd_ip *InstancePtr, u32 Mask);
void XAdd_ip_InterruptClear(XAdd_ip *InstancePtr, u32 Mask);
u32 XAdd_ip_InterruptGetEnabled(XAdd_ip *InstancePtr);
u32 XAdd_ip_InterruptGetStatus(XAdd_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
