// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xadd_ip.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAdd_ip_CfgInitialize(XAdd_ip *InstancePtr, XAdd_ip_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAdd_ip_Start(XAdd_ip *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_AP_CTRL) & 0x80;
    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAdd_ip_IsDone(XAdd_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAdd_ip_IsIdle(XAdd_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAdd_ip_IsReady(XAdd_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAdd_ip_EnableAutoRestart(XAdd_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XAdd_ip_DisableAutoRestart(XAdd_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_AP_CTRL, 0);
}

void XAdd_ip_Set_feat_in1(XAdd_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN1_DATA, (u32)(Data));
    XAdd_ip_WriteReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN1_DATA + 4, (u32)(Data >> 32));
}

u64 XAdd_ip_Get_feat_in1(XAdd_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN1_DATA);
    Data += (u64)XAdd_ip_ReadReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN1_DATA + 4) << 32;
    return Data;
}

void XAdd_ip_Set_feat_in2(XAdd_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN2_DATA, (u32)(Data));
    XAdd_ip_WriteReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN2_DATA + 4, (u32)(Data >> 32));
}

u64 XAdd_ip_Get_feat_in2(XAdd_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN2_DATA);
    Data += (u64)XAdd_ip_ReadReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_IN2_DATA + 4) << 32;
    return Data;
}

void XAdd_ip_Set_feat_out(XAdd_ip *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_OUT_DATA, (u32)(Data));
    XAdd_ip_WriteReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XAdd_ip_Get_feat_out(XAdd_ip *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_OUT_DATA);
    Data += (u64)XAdd_ip_ReadReg(InstancePtr->Control_BaseAddress, XADD_IP_CONTROL_ADDR_FEAT_OUT_DATA + 4) << 32;
    return Data;
}

void XAdd_ip_Set_CH(XAdd_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_CH_DATA, Data);
}

u32 XAdd_ip_Get_CH(XAdd_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_CH_DATA);
    return Data;
}

void XAdd_ip_Set_H(XAdd_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_H_DATA, Data);
}

u32 XAdd_ip_Get_H(XAdd_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_H_DATA);
    return Data;
}

void XAdd_ip_Set_W(XAdd_ip *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_W_DATA, Data);
}

u32 XAdd_ip_Get_W(XAdd_ip *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_W_DATA);
    return Data;
}

void XAdd_ip_InterruptGlobalEnable(XAdd_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_GIE, 1);
}

void XAdd_ip_InterruptGlobalDisable(XAdd_ip *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_GIE, 0);
}

void XAdd_ip_InterruptEnable(XAdd_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_IER);
    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_IER, Register | Mask);
}

void XAdd_ip_InterruptDisable(XAdd_ip *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_IER);
    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_IER, Register & (~Mask));
}

void XAdd_ip_InterruptClear(XAdd_ip *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdd_ip_WriteReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_ISR, Mask);
}

u32 XAdd_ip_InterruptGetEnabled(XAdd_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_IER);
}

u32 XAdd_ip_InterruptGetStatus(XAdd_ip *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAdd_ip_ReadReg(InstancePtr->Ctrl_BaseAddress, XADD_IP_CTRL_ADDR_ISR);
}

